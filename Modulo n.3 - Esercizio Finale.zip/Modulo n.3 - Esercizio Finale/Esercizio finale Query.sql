/*

ESERCIZI TERZO MODULO

*/
USE AmalfiCoastHotel
GO

-- Query n�1 - Creazione View per analisi delle cancellazione

CREATE VIEW AC_ReservationCancelled AS (
	SELECT r.IdReservation,
		p.IdHotel,
		p.IdRooms,
		r.IdClients,
		r.CheckIn,
		r.Checkout,
		DATEDIFF(day, r.CheckIn, r.Checkout) as Night
	FROM Reservation r
	INNER JOIN RoomsPrice p
	ON p.IdRoomsPrice = r.IdRoomsPrice
	WHERE r.Cancelled = 1
	)

-- Query n�2 - Query di analisi delle Cancellazioni per Hotel

SELECT DISTINCT 
	h.HotelName AS Hotel, 
	SUM(r.Night) AS TotalNight,
	COUNT(r.night) AS NoCancelled
		FROM AC_ReservationCancelled r
		INNER JOIN Hotel h 
		ON r.IdHotel = h.IdHotel
		GROUP BY h.HotelName, r.Night

-- Query n�3 - View che riepiloga il Fatturato per Agenzia (senza Cancellazioni)

CREATE VIEW AC_AMOUNT_FOR_CATEGORYSALES AS (
	SELECT 
	cs.CategorySalesName,
	COUNT(r.IdReservation) AS NoReservation,
	SUM(r.ReservationAmount) As TotalAmount
	FROM Reservation r
	INNER JOIN CategorySales cs
	ON r.IdCategorySales = cs.IdCategorySales
	WHERE r.Cancelled = 0
	GROUP BY cs.CategorySalesName 
	)

-- Query n�4 - View con riepilogo prenotazioni per Nazione
	
CREATE VIEW AC_Reservation_for_State AS (
	SELECT 
	c.State,
	COUNT(c.State) AS NoReservation,
	SUM(r.ReservationAmount) AS TotalAmount
	FROM Reservation r
	INNER JOIN Clients c
	ON r.IdClients = c.IdClients
	WHERE r.Cancelled = 0
	GROUP BY c.State
	)

-- Query n�5 - View Prenotazioni odierne

CREATE VIEW AC_TodayReservation AS (
	SELECT r.IdReservation,
		ro.[N�Rooms],
		h.HotelName,
		CONCAT (c.FirstName,' ',c.SecondName,' ',c.LastName) AS ClientsName,
		c.BirthDate,
		c.Gender,
		c.State,
		r.CheckIn,
		r.Checkout,
		DATEDIFF (day, r.Checkin, r.Checkout) AS Night,
		r.ReservationAmount,
		cs.CategorySalesName
	FROM Reservation r
	INNER JOIN RoomsPrice rp
	ON r.IdRoomsPrice = rp.IdRoomsPrice
	INNER JOIN Clients c
	ON r.IdClients = c.IdClients
	INNER JOIN Rooms ro
	ON rp.IdRooms = ro.IdRooms
	INNER JOIN Hotel h
	ON rp.IdHotel = h.IdHotel
	INNER JOIN CategorySales cs
	ON r.IdCategorySales = cs.IdCategorySales
	WHERE r.Cancelled = 0 AND r.CheckIn = CONVERT (date, SYSDATETIME())
	)

-- Query n�6 - Statistiche sulle Prenotazioni per Hotel nel 2022
	
SELECT h.HotelName
	, SUM(r.ReservationAmount)	AS TotalSales
	, COUNT(r.IdReservation)	AS TotalReservation
	, AVG(r.ReservationAmount)	AS AveragePrice 
FROM Reservation r
INNER JOIN RoomsPrice rp
ON r.IdRoomsPrice = rp.IdRoomsPrice
INNER JOIN Hotel h
ON rp.IdHotel = h.IdHotel
WHERE YEAR(r.CheckIn) = 2022 AND r.Cancelled = 0
GROUP BY h.HotelName

-- Query n�7 - Riepilogo notti per Imposta di soggiorno 2022 per Citt�

SELECT h.City,
	SUM(Night) AS TotalNight
FROM (
		SELECT r.IdRoomsPrice
		, DATEDIFF(day, r.CheckIn, r.Checkout) AS Night
		FROM Reservation r
		WHERE r.Cancelled = 0 AND YEAR(r.CheckIn) = 2022
		GROUP BY r.IdRoomsPrice, DATEDIFF(day, r.CheckIn, r.Checkout)
	) AS tb1
INNER JOIN RoomsPrice rp
ON tb1.IdRoomsPrice = rp.IdRoomsPrice
INNER JOIN Hotel h
ON rp.IdHotel = h.IdHotel
GROUP BY h.City

-- Query n�8 - Creazione View delle prenotazioni 2023 per Calendario

CREATE VIEW AC_Reservation2023_for_Calendar AS 
( SELECT r.IdReservation,
		ro.[N�Rooms],
		h.HotelName,
		CONCAT (c.FirstName,' ',c.SecondName,' ',c.LastName) AS ClientsName,
		c.BirthDate,
		c.Gender,
		c.State,
		r.CheckIn,
		r.Checkout,
		DATEDIFF (day, r.Checkin, r.Checkout) AS Night,
		r.ReservationAmount,
		cs.CategorySalesName
FROM Reservation r
INNER JOIN RoomsPrice rp
ON r.IdRoomsPrice = rp.IdRoomsPrice
INNER JOIN CategorySales cs
ON r.IdCategorySales = cs.IdCategorySales
INNER JOIN Hotel h
ON rp.IdHotel = h.IdHotel
INNER JOIN Rooms ro
ON rp.IdRooms = ro.IdRooms
INNER JOIN Clients c
ON r.IdClients = c.IdClients
WHERE Cancelled = 0 AND YEAR(CheckIn) = 2023
)

-- Query n�9 - Camere non Vendute

SELECT rp.IdRooms
FROM Reservation r
LEFT JOIN RoomsPrice rp
ON r.IdRoomsPrice = rp.IdRoomsPrice
WHERE rp.IdRoomsPrice is null AND r.Cancelled = 1 
ORDER BY rp.IdRooms

-- Query n�10 - Analisi per Cliente (Vendite per Cliente con Numero di Prenotazioni)

SELECT c.IdClients,
		CONCAT (c.FirstName,' ',c.SecondName,' ',c.LastName) AS ClientsName,
		SUM(r.ReservationAmount) AS TotalAmount,
		COUNT (r.IdReservation) AS "N� Reservation"
FROM Reservation r
INNER JOIN RoomsPrice rp
ON r.IdRoomsPrice = rp.IdRoomsPrice
INNER JOIN CategorySales cs
ON r.IdCategorySales = cs.IdCategorySales
INNER JOIN Hotel h
ON rp.IdHotel = h.IdHotel
INNER JOIN Rooms ro
ON rp.IdRooms = ro.IdRooms
INNER JOIN Clients c
ON r.IdClients = c.IdClients
WHERE Cancelled = 0
GROUP BY c.IdClients, CONCAT (c.FirstName,' ',c.SecondName,' ',c.LastName)
ORDER BY TotalAmount DESC



	

