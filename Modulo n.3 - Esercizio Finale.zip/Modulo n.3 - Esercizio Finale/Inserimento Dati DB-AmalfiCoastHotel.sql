-- Query di inserimento dati --

INSERT INTO CategoryHotel (IdCategoryHotel, CategoryHotelName)
	VALUES
	('1', '5 Star'),('2', '4 Star'),('3','3 Star'),('4','2 Star'),('5','1 Star'),('6','Resort'),('7','Villas');
	
INSERT INTO CategoryRooms (IdCategoryRooms, CategoryRoomsName)
	VALUES
	('1', 'Standard Room'),('2', 'Confort Room'),('3','Deluxe Room'),('4','Junior Suite'),('5','Suite');

INSERT INTO HotelTreatment (IdHotelTreatment, HotelTreatmentName)
	VALUES
	('1', 'Room Only'),('2', 'Bed & Breakfast'),('3','Half Board'),('4','Full Board');

ALTER TABLE CategorySales
ALTER COLUMN SalesCommission DECIMAL (4,2)

INSERT INTO CategorySales (IdCategorySales, CategorySalesName, SalesCommission, "Address", Zipcode, City, "State", Telephone, Email)
	VALUES
	('1','Direct','0','','','','','',''),
	('2','Booking.com','15','','','Amsterdam','Netherlands','',''),
	('3','Trivago','18','','','Dussekdorf','Germany','',''),
	('4','AirBnb','9','','','San Francisco','United States of America','',''),
	('5','Expedia','21','333 108th Avenue NE','','Bellevue','United States of America','','');

INSERT INTO Employee (IdEmployee, LastName, FirstName, "Address", City, Telephone)
	VALUES
	('1','Cassano', 'Roberto', 'Via Galileo Galilei', 'Isernia', '3992945127'),
	('2','Mariani', 'Riccardo', 'piazza Manzoni', 'Palermo', '3991293974');
	('3','Serra', 'Matteo', 'Via Galileo Galilei', 'Trieste', 3999570944),
	('4','Conte', 'Elisa', 'piazza Marconi', 'Lecco', 3998618536),
	('5','Bernardi', 'Enea', 'Via Alessandro Volta', 'Napoli', 3996620136),
	('6','Bruno', 'Andrea', 'piazza XXV Aprile', 'Palermo', 3993720439),
	('7','Fontana', 'Alice', 'piazza IV Novembre', 'Benevento', 3999699617),
	('8','Rossetti', 'Matteo', 'piazza Giuseppe Verdi', 'Alessandria', 3997173684),
	('9','Mazza', 'Ginevra', 'piazza Enrico Fermi', 'Lucca', 3996271435),
	('10','Farina', 'Marco', 'Via Leopardi', 'Lucca', 3995525737),
	('11','Ricci', 'Gabriele', 'piazza Mazzini', 'Ravenna', 3991501680),
	('12','Ferri', 'Anna', 'piazza Alcide De Gasperi', 'Catania', 3995432568),
	('13','Bianchi', 'Giorgia', 'Via Antonio Gramsci', 'Torino', 3999791911),
	('14','Lombardi', 'Marco', 'Via Marconi', 'Parigi', 3997153373),
	('15','Martinelli', 'Elia', 'piazza Leopardi', 'Avellino', 3995991646),
	('16','Giordano', 'Roberto', 'piazza Marconi', 'Aquila', 3995219374),
	('17','Serra', 'Giulia', 'piazza Roma', 'Foggia', 3994738816);



