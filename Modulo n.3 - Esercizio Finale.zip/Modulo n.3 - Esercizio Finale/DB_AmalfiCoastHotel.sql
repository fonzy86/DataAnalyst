CREATE DATABASE "AmalfiCoastHotel"
GO

USE AmalfiCoastHotel
GO

CREATE TABLE "CategoryHotel" (
	IdCategoryHotel INT PRIMARY KEY,
	CategoryHotelName VARCHAR(25) NOT NULL
	)

CREATE TABLE "CategoryRooms" (
	IdCategoryRooms INT PRIMARY KEY,
	CategoryRoomsName VARCHAR(25) NOT NULL
	)

CREATE TABLE "HotelTreatment" (
	IdHotelTreatment INT PRIMARY KEY,
	HotelTreatmentName VARCHAR(25) NOT NULL
	)

CREATE TABLE "Employee" (
	IdEmployee	INT PRIMARY KEY,
	FirstName VARCHAR(25) NOT NULL,
	SecondName VARCHAR(25),
	LastName VARCHAR(25) NOT NULL,
	"Address" VARCHAR(50),
	Zipcode VARCHAR(5),
	City VARCHAR(25),
	"State" VARCHAR(25),
	Telephone VARCHAR(25),
	Email VARCHAR(50)
	)

CREATE TABLE "Clients" (
	IdClients INT PRIMARY KEY,
	FirstName VARCHAR(25) NOT NULL,
	SecondName VARCHAR(25),
	LastName VARCHAR(25) NOT NULL,
	"Address" VARCHAR(50),
	Zipcode VARCHAR(5),
	City VARCHAR(25),
	"State" VARCHAR(25),
	Telephone VARCHAR(25),
	Email VARCHAR(50)
	)

CREATE TABLE "CategorySales" (
	IdCategorySales INT PRIMARY KEY,
	CategorySalesName VARCHAR(25) NOT NULL,
	SalesCommission DECIMAL(2,2),
	"Address" VARCHAR(50),
	Zipcode VARCHAR(5),
	City VARCHAR(25),
	"State" VARCHAR(25),
	Telephone VARCHAR(25),
	Email VARCHAR(50)
	)

CREATE TABLE "Hotel" (
	IdHotel INT PRIMARY KEY,
	IdCategoryHotel INT FOREIGN KEY REFERENCES CategoryHotel (IdCategoryHotel),
	HotelName VARCHAR(25),
	"Address" VARCHAR(50),
	Zipcode VARCHAR(5),
	City VARCHAR(25),
	"State" VARCHAR(25),
	Telephone VARCHAR(25),
	EmailReception VARCHAR(50)
	)

CREATE TABLE "Rooms" (
	IdRooms INT PRIMARY KEY,
	IdHotel	INT FOREIGN KEY REFERENCES Hotel (IdHotel),
	IdCategoryRooms INT FOREIGN KEY REFERENCES CategoryRooms (IdCategoryRooms),
	"N�Rooms" INT NOT NULL,
	Bed TINYINT NOT NULL,
	TotalGuest TINYINT NOT NULL,
	)

CREATE TABLE "RoomsPrice" (
	IdRoomsPrice INT PRIMARY KEY,
	IdRooms INT FOREIGN KEY REFERENCES Rooms (IdRooms),
	IdHotel INT FOREIGN KEY REFERENCES Hotel (IdHotel),
	IdHotelTreatment INT FOREIGN KEY REFERENCES HotelTreatment (IdHotelTreatment) NOT NULL,
	DateStart DATE NOT NULL,
	DateEnd DATE,
	Price MONEY NOT NULL,
	IdEmployee INT FOREIGN KEY REFERENCES Employee (IdEmployee) NOT NULL,
	LastEdit SMALLDATETIME NOT NULL
	)

CREATE TABLE "Reservation" (
	IdReservation INT PRIMARY KEY,
	IdRoomsPrice INT FOREIGN KEY REFERENCES RoomsPrice (IdRoomsPrice),
	IdCategorySales INT FOREIGN KEY REFERENCES CategorySales (IdCategorySales),
	"N�Sales" VARCHAR(25),
	IdClients INT FOREIGN KEY REFERENCES Clients (IdClients),
	CheckIn	DATE NOT NULL,
	Checkout DATE NOT NULL,
	"N�Guest" TINYINT NOT NULL,
	ReservationAmount MONEY NOT NULL,
	Cancelled BIT,
	IdEmployee INT FOREIGN KEY REFERENCES Employee (IdEmployee) NOT NULL,
	LastEdit SMALLDATETIME NOT NULL
	)
