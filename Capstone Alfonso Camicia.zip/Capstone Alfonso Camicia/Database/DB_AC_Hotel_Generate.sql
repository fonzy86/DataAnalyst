CREATE DATABASE AmalfiCoast_Hotels

USE AmalfiCoast_Hotels
GO

CREATE TABLE "DimState" (
	IdState INT PRIMARY KEY,
	StateName VARCHAR(100),
	CapitalState VARCHAR(50),
	TimeZone VARCHAR(15)
	)

CREATE TABLE "DimItalianCity" (
	IdITCity INT PRIMARY KEY,
	ITCityName VARCHAR(50),
	ProvinceSigle VARCHAR(2),
	CityCode VARCHAR(5)
	)

CREATE TABLE "DimCategoryHotel" (
	IdCategoryHotel INT PRIMARY KEY,
	CategoryHotelName VARCHAR(25) NOT NULL
	)

CREATE TABLE "DimCategoryRooms" (
	IdCategoryRooms INT PRIMARY KEY,
	CategoryRoomsName VARCHAR(25) NOT NULL
	)

CREATE TABLE "DimHotelTreatment" (
	IdHotelTreatment INT PRIMARY KEY,
	HotelTreatmentName VARCHAR(25) NOT NULL,
	Price MONEY
	)

CREATE TABLE "DimService" (
	IdService INT PRIMARY KEY,
	ServiceName VARCHAR(25) NOT NULL,
	Price MONEY
	)

CREATE TABLE "DimEmployee" (
	IdEmployee	INT PRIMARY KEY,
	FirstName VARCHAR(25) NOT NULL,
	SecondName VARCHAR(25),
	LastName VARCHAR(25) NOT NULL,
	"Address" VARCHAR(50),
	IdITCity INT REFERENCES DimItalianCity (IdITCity),
	IdState INT REFERENCES DimState (IdState),
	Telephone VARCHAR(25),
	Email VARCHAR(50),
	ProfessionalRole VARCHAR(25),
	DateofBirth DATE,
	IdITCityOfBirth INT REFERENCES DimItalianCity (IdITCity),
	IdITStateOfBirth INT REFERENCES DimState (IdState)
	)

CREATE TABLE "DimClients" (
	IdClients INT PRIMARY KEY,
	FirstName VARCHAR(25) NOT NULL,
	SecondName VARCHAR(25),
	LastName VARCHAR(25) NOT NULL,
	"Address" VARCHAR(50),
	IdITCity INT REFERENCES DimItalianCity (IdITCity),
	IdState INT REFERENCES DimState (IdState),
	Telephone VARCHAR(25),
	Email VARCHAR(50),
	DateofBirth DATE,
	IdITCityOfBirth INT REFERENCES DimItalianCity (IdITCity),
	IdITStateOfBirth INT REFERENCES DimState (IdState)
	)

CREATE TABLE "DimCategorySales" (
	IdCategorySales INT PRIMARY KEY,
	CategorySalesName VARCHAR(25) NOT NULL,
	SalesCommission DECIMAL(4,2),
	"Address" VARCHAR(50),
	Zipcode VARCHAR(5),
	City VARCHAR(25),
	IdState INT REFERENCES DimState (IdState),
	Telephone VARCHAR(25),
	Email VARCHAR(50),
	VATNumber VARCHAR(25)
	)

CREATE TABLE "DimHotel" (
	IdHotel INT PRIMARY KEY,
	IdCategoryHotel INT REFERENCES DimCategoryHotel (IdCategoryHotel),
	HotelName VARCHAR(25) NOT NULL,
	"Address" VARCHAR(50),
	IdITCity INT REFERENCES DimItalianCity (IdITCity),
	IdState INT REFERENCES DimState (IdState),
	Telephone VARCHAR(25),
	EmailReception VARCHAR(50)
	)

CREATE TABLE "DimRooms" (
	IdRooms INT PRIMARY KEY,
	IdHotel	INT REFERENCES DimHotel (IdHotel),
	IdCategoryRooms INT REFERENCES DimCategoryRooms (IdCategoryRooms),
	"N�Rooms" INT NOT NULL,
	Bed TINYINT NOT NULL,
	TotalGuest TINYINT NOT NULL,
	)

CREATE TABLE "FactRoomsRate" (
	IdRoomsRate INT PRIMARY KEY,
	IdRooms INT FOREIGN KEY REFERENCES DimRooms (IdRooms),
	IdHotel INT FOREIGN KEY REFERENCES DimHotel (IdHotel),
	DateStart DATE NOT NULL,
	DateEnd DATE,
	Price MONEY NOT NULL,
	IdEmployee INT FOREIGN KEY REFERENCES DimEmployee (IdEmployee) NOT NULL,
	LastEdit SMALLDATETIME NOT NULL
	)

CREATE TABLE "FactReservation" (
	IdReservation INT PRIMARY KEY,
	IdRoomsRate INT FOREIGN KEY REFERENCES FactRoomsRate (IdRoomsRate),
	IdCategorySales INT FOREIGN KEY REFERENCES DimCategorySales (IdCategorySales),
	IdHotelTreatment INT FOREIGN KEY REFERENCES DimHotelTreatment (IdHotelTreatment),
	IdService INT FOREIGN KEY REFERENCES DimService (IdService),
	IdClients INT FOREIGN KEY REFERENCES DimClients (IdClients),
	CheckIn	DATE NOT NULL,
	Checkout DATE NOT NULL,
	"N�Guest" TINYINT NOT NULL,
	ReservationAmount MONEY NOT NULL,
	ReservationDate DATE NOT NULL,
	Cancelled BIT,
	IdEmployee INT FOREIGN KEY REFERENCES DimEmployee (IdEmployee) NOT NULL,
	LastEdit SMALLDATETIME NOT NULL
	)
