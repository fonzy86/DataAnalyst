CREATE VIEW AC_Hotels AS (
	SELECT r.IdReservation,
		p.IdHotel,
		p.IdRooms,
		r.IdClients,
		r.CheckIn,
		r.Checkout,
		DATEDIFF(day, r.CheckIn, r.Checkout) as Night
	FROM FactReservation r
	INNER JOIN FactRoomsRate p
	ON p.IdRoomsRate = r.IdRoomsRate
	WHERE r.Cancelled = 1
	)

CREATE VIEW AC_TotalReservation2023 AS
( SELECT r.IdReservation,
		ro.[N�Rooms],
		h.HotelName,
		CONCAT (c.FirstName,' ',c.SecondName,' ',c.LastName) AS ClientsName,
		c.DateofBirth,
		st.StateName,
		r.CheckIn,
		r.Checkout,
		DATEDIFF (day, r.Checkin, r.Checkout) AS Night,
		r.ReservationAmount,
		cs.CategorySalesName,
		r.Cancelled
FROM FactReservation r
INNER JOIN FactRoomsRate rp
ON r.IdRoomsRate = rp.IdRoomsRate
INNER JOIN DimCategorySales cs
ON r.IdCategorySales = cs.IdCategorySales
INNER JOIN DimHotel h
ON rp.IdHotel = h.IdHotel
INNER JOIN DimRooms ro
ON rp.IdRooms = ro.IdRooms
INNER JOIN DimClients c
ON r.IdClients = c.IdClients
INNER JOIN DimState st
ON c.IdState = st.IdState
WHERE YEAR(CheckIn) = 2023
)

CREATE VIEW AC_AMOUNT_FOR_CATEGORYSALES2023 AS (
	SELECT 
	cs.CategorySalesName,
	COUNT(r.IdReservation) AS NoReservation,
	SUM(r.ReservationAmount) As TotalAmount
	FROM FactReservation r
	INNER JOIN DimCategorySales cs
	ON r.IdCategorySales = cs.IdCategorySales
	WHERE r.Cancelled = 0 AND YEAR(CheckIn) = 2023
	GROUP BY cs.CategorySalesName 
	)

CREATE VIEW AC_TommorrowReservation AS (
	SELECT r.IdReservation,
		ro.[N�Rooms],
		h.HotelName,
		CONCAT (c.FirstName,' ',c.SecondName,' ',c.LastName) AS ClientsName,
		c.DateofBirth,
		st.StateName,
		r.CheckIn,
		r.Checkout,
		DATEDIFF (day, r.Checkin, r.Checkout) AS Night,
		r.ReservationAmount,
		cs.CategorySalesName,
		rp.Price AS RoomRate,
		ht.HotelTreatmentName,
		ht.PriceForPerson AS PriceForPersonHotelTreatment,
		se.ServiceName,
		se.Price AS ServicePrice
	FROM FactReservation r
	INNER JOIN FactRoomsRate rp
	ON r.IdRoomsRate = rp.IdRoomsRate
	INNER JOIN DimClients c
	ON r.IdClients = c.IdClients
	INNER JOIN DimRooms ro
	ON rp.IdRooms = ro.IdRooms
	INNER JOIN DimHotel h
	ON rp.IdHotel = h.IdHotel
	INNER JOIN DimCategorySales cs
	ON r.IdCategorySales = cs.IdCategorySales
	INNER JOIN DimService se
	ON r.IdService = se.IdService
	INNER JOIN DimHotelTreatment ht
	ON r.IdHotelTreatment = ht.IdHotelTreatment
	INNER JOIN DimState st
	ON c.IdState = st.IdState
	WHERE r.Cancelled = 0 AND r.CheckIn = GETDATE()+1
	)